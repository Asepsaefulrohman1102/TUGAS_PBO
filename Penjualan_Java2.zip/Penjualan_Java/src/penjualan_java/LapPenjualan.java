/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package penjualan_java;

import java.io.File;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author ACER
 */
public class LapPenjualan extends javax.swing.JFrame {

    /**
     * Creates new form LapPenjualan
     */
//    Connection Con;
//    ResultSet RsJual;
//    Statement stm;
//    PreparedStatement pstat;
//    String tgl1,tgl2;
//    private Object[][] dataTable = null;
//    private String[] header = {"No Jual","Tanggal","Nama Konsumen","Kode Barang","Nama Barang","Harga Satuan","Jumlah","Total"};
//    DefaultTableModel tableModel = new DefaultTableModel(new Object [][] {},header);

    Connection Con;
    ResultSet RsJual;
    Statement stm;
    PreparedStatement pstat;
    String tgl1,tgl2;
    private Object[][] dataTable = null;
    private String[] header = {"No Jual","Tanggal","Nama Konsumen","Kode Barang","Nama Barang","Harga Satuan","Jumlah","Total"};
    DefaultTableModel tableModel = new DefaultTableModel(new Object [][] {},header);
    

    private void open_db()
    {
        try{
            KoneksiMysql kon = new KoneksiMysql ("localhost","root","","penjualan_java");
            Con = kon.getConnection();
        }catch (Exception e) {
            System.out.println("Error : "+e);
        }
    }
    
    private void baca_data() {
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            tgl1=sdf.format(dtAwal.getDate());
            tgl2=sdf.format(dtAkhir.getDate());
            stm = Con.createStatement();
            pstat = Con.prepareStatement("SELECT a.no_jual,a.tgl_jual,c.nm_kons,d.kd_brg,d.nm_brg,b.harga_jual,b.jml_jual,(b.harga_jual*b.jml_jual) AS 'totjual' " +
            "FROM jual a LEFT JOIN djual b ON (a.no_jual=b.no_jual) " +
            "LEFT JOIN konsumen c ON (a.kd_kons=c.kd_kons) " +
            "LEFT JOIN barang d ON (b.kd_brg=d.kd_brg)" +
            "where date(a.tgl_jual)>=" + "date('"+ tgl1+"') and date(a.tgl_jual)<=" + "date('"+tgl2+"')order by a.tgl_jual desc",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            RsJual = pstat.executeQuery();
            ResultSetMetaData meta = RsJual.getMetaData();
            int col = meta.getColumnCount();
            int baris = 0;
            while(RsJual.next()) {
                baris = RsJual.getRow();
            }
            dataTable = new Object[baris][col];
            int x = 0;
            RsJual.beforeFirst();
            while(RsJual.next()) {
                dataTable[x][0] = RsJual.getString("no_jual");
                dataTable[x][1] = RsJual.getDate("tgl_jual");
                dataTable[x][2] = RsJual.getString("nm_kons");
                dataTable[x][3] = RsJual.getString("kd_brg");
                dataTable[x][4] = RsJual.getString("nm_brg");
                dataTable[x][5] = RsJual.getDouble("harga_jual");
                dataTable[x][6] = RsJual.getInt("jml_jual");
                dataTable[x][7] = RsJual.getDouble("totjual");
            x++;
            }
            tblLapJual.setModel(new DefaultTableModel(dataTable,header));
        }catch(SQLException e){
             JOptionPane.showMessageDialog(null, e);
        }
        
    }




//    private void baca_data()
//    {
//        try{
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//            tgl1=sdf.format(dtAwal.getDate());
//            tgl2=sdf.format(dtAkhir.getDate());
//            stm = Con.createStatement();
////            pstat = Con.prepareStatement("SELECT a.no_jual,a.tgl_jual,c.nm_kons,d.kd_brg,d.nm_brg,b.harga_jual,b.jml_jual,(b.harga_jual*b.jml_jual) AS 'totjual' " +
////            "FROM jual a LEFT JOIN djual b ON (a.no_jual=b.no_jual) " +
////            "LEFT JOIN konsumen c ON (a.kd_kons=c.kd_kons) " +
////            "LEFT JOIN barang d ON (b.kd_brg=d.kd_brg)" + "where date(a.tgl_jual)>=" + "date('"+ tgl1+"') and date(a.tgl_jual)<=" + "date('"+tgl2+"') order by a.tgl_jual desc",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
//
//            pstat = Con.prepareStatement("SELECT a.no_jual, a.tgl_jual, c.nm_kons, d.kd_brg, d.nm_brg, b.harga_jual, b.jml_jual, (b.harga_jual * b.jml_jual) AS 'totjual' " +
//            "FROM jual a LEFT JOIN djual b ON (a.no_jual = b.no_jual) " +
//            "LEFT JOIN konsumen c ON (a.kd_kons = c.kd_kons) " +
//            "LEFT JOIN barang d ON (b.kd_brg = d.kd_brg) " + // Tambahkan spasi setelah kata kunci "LEFT JOIN barang d ON (b.kd_brg = d.kd_brg)"
//            "WHERE DATE(a.tgl_jual) >= DATE('" + tgl1 + "') AND DATE(a.tgl_jual) <= DATE('" + tgl2 + "') ORDER BY a.tgl_jual DESC", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//
//            RsJual = pstat.executeQuery();
//            ResultSetMetaData meta = RsJual.getMetaData();
//            int col = meta.getColumnCount();
//            int baris = 0;
//            
//            while(RsJual.next()) {
//                baris = RsJual.getRow();
//            }
//            
//            dataTable = new Object[baris][col];
//            int x = 0;
//            RsJual.beforeFirst();
//            
//            while(RsJual.next()) {
//                dataTable[x][0] = RsJual.getString("no_jual");
//                dataTable[x][1] = RsJual.getDate("tgl_jual");
//                dataTable[x][2] = RsJual.getString("nm_kons");
//                dataTable[x][3] = RsJual.getString("kd_brg");
//                dataTable[x][4] = RsJual.getString("nm_brg");
//                dataTable[x][5] = RsJual.getDouble("harga_jual");
//                dataTable[x][6] = RsJual.getInt("jml_jual");
//                dataTable[x][7] = RsJual.getDouble("totjual");
//                x++;
//            }
//            tblLapJual.setModel(new DefaultTableModel(dataTable,header));
//        }catch(SQLException e){
//            JOptionPane.showMessageDialog(null, e.getMessage()); // Tampilkan pesan kesalahan
//        }
//
//    }
    
//    private void baca_data() {
//    try {
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", new Locale("id", "ID"));
//
//        Date awal = dtAwal.getDate();
//        Date akhir = dtAkhir.getDate();
//
//        if (awal != null && akhir != null) {
//            tgl1 = formatter.format(awal.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
//            tgl2 = formatter.format(akhir.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
//
//            String query = "SELECT a.no_jual, a.tgl_jual, c.nm_kons, d.kd_brg, d.nm_brg, b.harga_jual, 
//                            b.jml_jual, (b.harga_jual * b.jml_jual) AS 'totjual' " +
//                    "FROM jual a LEFT JOIN djual b ON (a.no_jual = b.no_jual) " +
//                    "LEFT JOIN konsumen c ON (a.kd_kons = c.kd_kons) " +
//                    "LEFT JOIN barang d ON (b.kd_brg = d.kd_brg) " +
//                    "WHERE DATE(a.tgl_jual) >= ? AND DATE(a.tgl_jual) <= ? ORDER BY a.tgl_jual DESC";
//
//            pstat = Con.prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//            pstat.setString(1, tgl1);
//            pstat.setString(2, tgl2);
//
//            RsJual = pstat.executeQuery();
//            ResultSetMetaData meta = RsJual.getMetaData();
//            int col = meta.getColumnCount();
//            int baris = 0;
//
//            while (RsJual.next()) {
//                baris = RsJual.getRow();
//            }
//
//            dataTable = new Object[baris][col];
//            int x = 0;
//            RsJual.beforeFirst();
//
//            while (RsJual.next()) {
//                dataTable[x][0] = RsJual.getString("no_jual");
//                dataTable[x][1] = formatter.format(RsJual.getDate("tgl_jual").toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
//                dataTable[x][2] = RsJual.getString("nm_kons");
//                dataTable[x][3] = RsJual.getString("kd_brg");
//                dataTable[x][4] = RsJual.getString("nm_brg");
//                dataTable[x][5] = RsJual.getDouble("harga_jual");
//                dataTable[x][6] = RsJual.getInt("jml_jual");
//                dataTable[x][7] = RsJual.getDouble("totjual");
//                x++;
//            }
//            tblLapJual.setModel(new DefaultTableModel(dataTable, header));
//        } else {
//            JOptionPane.showMessageDialog(null, "Silakan pilih tanggal awal dan tanggal akhir terlebih dahulu.");
//        }
//    } catch (SQLException e) {
//        JOptionPane.showMessageDialog(null, e.getMessage());
//    }
//}


    
    
    public LapPenjualan() {
        initComponents();
        dtAwal.setDate(new Date());
        dtAkhir.setDate(new Date());
        open_db() ;
        baca_data();
//        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//        open_db();
//
//        Date tanggalAwal = dtAwal.getDate();
//        Date tanggalAkhir = dtAkhir.getDate();
//
//        if (tanggalAwal == null && tanggalAkhir == null) {
//            tgl1 = sdf.format(tanggalAwal);
//            tgl2 = sdf.format(tanggalAkhir);
//            baca_data();
//        } else {
//            // Tangani kasus ketika tanggal awal atau tanggal akhir tidak dipilih
//            baca_data();
//        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        dtAwal = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        dtAkhir = new com.toedter.calendar.JDateChooser();
        cmdCari = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLapJual = new javax.swing.JTable();
        cmdExport = new javax.swing.JButton();
        cmdKeluar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Tanggal");

        dtAwal.setDateFormatString("yyyy-MM-dd\n");

        jLabel2.setText("S/D");

        dtAkhir.setDateFormatString("yyyy-MM-dd");

        cmdCari.setText("Cari");
        cmdCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdCariActionPerformed(evt);
            }
        });

        tblLapJual.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        tblLapJual.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No Jual", "Tanggal", "Nama Konsumen", "Kode  Barang", "Nama Barang", "Harga Satuan", "Jumlah", "Total"
            }
        ));
        jScrollPane1.setViewportView(tblLapJual);

        cmdExport.setText("Export");
        cmdExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdExportActionPerformed(evt);
            }
        });

        cmdKeluar.setText("Keluar");
        cmdKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdKeluarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("LAPORAN PENJUALAN");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cmdExport, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(426, 426, 426)
                        .addComponent(cmdKeluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(428, 428, 428))
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(dtAwal, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(98, 98, 98)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(dtAkhir, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(cmdCari, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(66, 66, 66))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cmdCari, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(dtAkhir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dtAwal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(38, 38, 38)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmdExport, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cmdKeluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmdCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdCariActionPerformed
        // TODO add your handling code here:
        baca_data();
    }//GEN-LAST:event_cmdCariActionPerformed

    private void cmdExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdExportActionPerformed
        // TODO add your handling code here:
        try{
            ExportToExcel ex =new ExportToExcel(tblLapJual, new File("DataPenjualan.xls"));
            //exportToExcel(tblBrg, new File("DataBarang.xls"));
            JOptionPane.showMessageDialog(null, "Sukses Export data .....");
            }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_cmdExportActionPerformed

    private void cmdKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdKeluarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_cmdKeluarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LapPenjualan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LapPenjualan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LapPenjualan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LapPenjualan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LapPenjualan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cmdCari;
    private javax.swing.JButton cmdExport;
    private javax.swing.JButton cmdKeluar;
    private com.toedter.calendar.JDateChooser dtAkhir;
    private com.toedter.calendar.JDateChooser dtAwal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblLapJual;
    // End of variables declaration//GEN-END:variables
}
