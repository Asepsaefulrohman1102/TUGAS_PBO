-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: penjualan_java
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `barang`
--

DROP TABLE IF EXISTS `barang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barang` (
  `kd_brg` varchar(6) NOT NULL,
  `nm_brg` varchar(30) DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `stok` int(5) DEFAULT NULL,
  `stok_min` int(5) DEFAULT NULL,
  PRIMARY KEY (`kd_brg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barang`
--

LOCK TABLES `barang` WRITE;
/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
INSERT INTO `barang` VALUES ('B001','buku','buah',4000,76,10),('B002','pensil','buah',2500,48,10),('B003','penghapus','buah',2000,17,10),('B004','spidol','buah',6000,26,10),('B005','papan tulis','buah',25000,38,10),('B006','pensil warna','buah',10000,10,10),('B007','stabilo','buah',3000,66,10),('B008','tipe-x','buah',4000,78,10),('B009','binder','buah',25000,60,10),('B010','kertas tipis','Buah',500,90,10);
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djual`
--

DROP TABLE IF EXISTS `djual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djual` (
  `no_jual` varchar(10) NOT NULL DEFAULT 'T0',
  `kd_brg` char(6) NOT NULL,
  `nm_kons` varchar(30) NOT NULL,
  `harga_jual` float DEFAULT NULL,
  `jml_jual` int(4) DEFAULT NULL,
  PRIMARY KEY (`no_jual`,`kd_brg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djual`
--

LOCK TABLES `djual` WRITE;
/*!40000 ALTER TABLE `djual` DISABLE KEYS */;
INSERT INTO `djual` VALUES ('T001','B001','Asep',4000,2),('T002','B002','Asep',2500,2),('T002','B004','Asep',6000,2),('T002','B007','Asep',3000,4),('T003','B001','Asep',4000,2),('T003','B004','Asep',6000,2);
/*!40000 ALTER TABLE `djual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jual`
--

DROP TABLE IF EXISTS `jual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jual` (
  `no_jual` varchar(10) NOT NULL,
  `kd_kons` char(6) DEFAULT NULL,
  `tgl_jual` date DEFAULT NULL,
  PRIMARY KEY (`no_jual`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jual`
--

LOCK TABLES `jual` WRITE;
/*!40000 ALTER TABLE `jual` DISABLE KEYS */;
INSERT INTO `jual` VALUES ('T001','K001','2023-06-17'),('T002','K001','2023-06-22'),('T003','K001','2023-06-23');
/*!40000 ALTER TABLE `jual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konsumen`
--

DROP TABLE IF EXISTS `konsumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `konsumen` (
  `kd_kons` varchar(6) NOT NULL,
  `nm_kons` varchar(30) DEFAULT NULL,
  `alm_kons` varchar(50) DEFAULT NULL,
  `kota_kons` varchar(20) DEFAULT NULL,
  `kd_pos` varchar(5) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`kd_kons`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konsumen`
--

LOCK TABLES `konsumen` WRITE;
/*!40000 ALTER TABLE `konsumen` DISABLE KEYS */;
INSERT INTO `konsumen` VALUES ('K001','Asep','Semarang','Semarang','52263','08123456778','A@gmail.com'),('K002','Nama Konsumen 1','Alamat Konsumen 1','Kota Konsumen 1','12345','1234567890','email1@example.com'),('K003','Nama Konsumen 2','Alamat Konsumen 2','Kota Konsumen 2','23456','2345678901','email2@example.com'),('K004','Nama Konsumen 3','Alamat Konsumen 3','Kota Konsumen 3','34567','3456789012','email3@example.com'),('K005','Nama Konsumen 4','Alamat Konsumen 4','Kota Konsumen 4','45678','4567890123','email4@example.com'),('K006','Nama Konsumen 5','Alamat Konsumen 5','Kota Konsumen 5','56789','5678901234','email5@example.com'),('K007','Nama Konsumen 6','Alamat Konsumen 6','Kota Konsumen 6','67890','6789012345','email6@example.com'),('K008','Nama Konsumen 7','Alamat Konsumen 7','Kota Konsumen 7','78901','7890123456','email7@example.com'),('K009','Nama Konsumen 8','Alamat Konsumen 8','Kota Konsumen 8','89012','8901234567','email8@example.com'),('K010','Nama Konsumen 9','Alamat Konsumen 9','Kota Konsumen 9','90123','9012345678','email9@example.com'),('K011','Nama Konsumen 10','Alamat Konsumen 10','Kota Konsumen 10','01234','0123456789','email10@example.com'),('K012','Nama Konsumen 11','Alamat Konsumen 11','Kota Konsumen 11','12345','1234567890','email11@example.com'),('K013','Nama Konsumen 12','Alamat Konsumen 12','Kota Konsumen 12','23456','2345678901','email12@example.com'),('K014','Nama Konsumen 13','Alamat Konsumen 13','Kota Konsumen 13','34567','3456789012','email13@example.com'),('K015','Nama Konsumen 14','Alamat Konsumen 14','Kota Konsumen 14','45678','4567890123','email14@example.com'),('K016','Nama Konsumen 15','Alamat Konsumen 15','Kota Konsumen 15','56789','5678901234','email15@example.com'),('K017','Nama Konsumen 16','Alamat Konsumen 16','Kota Konsumen 16','67890','6789012345','email16@example.com'),('K018','Nama Konsumen 17','Alamat Konsumen 17','Kota Konsumen 17','78901','7890123456','email17@example.com'),('K019','Nama Konsumen 18','Alamat Konsumen 18','Kota Konsumen 18','89012','8901234567','email18@example.com'),('K020','Nama Konsumen 19','Alamat Konsumen 19','Kota Konsumen 19','90123','9012345678','email19@example.com'),('K021','Nama Konsumen 20','Alamat Konsumen 20','Kota Konsumen 20','01234','0123456789','email20@example.com');
/*!40000 ALTER TABLE `konsumen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `password` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'user','user','ee11cbb19052e40b07aac0ca060c23ee');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-23 13:05:28
